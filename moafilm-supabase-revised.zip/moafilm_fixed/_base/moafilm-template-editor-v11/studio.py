#!/usr/bin/env python3
"""MoaFilm Canva background MP4 template studio. Local-only, not a payment service."""
import base64, json, re, subprocess, uuid, threading, time, shutil, mimetypes, os, hmac, smtplib, ssl, email.message
import security
from marker_detector import detect_video
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote
from PIL import Image
ROOT=Path(os.environ.get('MOAFILM_DATA_DIR',str(Path(__file__).resolve().parent)))
ROOT.mkdir(parents=True,exist_ok=True)
for p in ('templates','backgrounds','photos','outputs','jobs','music','scenes'): (ROOT/p).mkdir(exist_ok=True)
HOST=os.environ.get('MOAFILM_HOST','127.0.0.1'); PORT=int(os.environ.get('PORT','8890'))
FONT='/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
if not Path(FONT).exists():FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
JOBS={}
# In-memory abuse guard: per-IP and per-account buckets. For multi-worker deployment,
# replace with a shared Redis-backed limiter.
RATE_LOCK=threading.Lock()
RATE={}
def check_rate(key,limit,window=300):
 now=time.monotonic()
 with RATE_LOCK:
  hits=[x for x in RATE.get(key,[]) if now-x<window]
  if len(hits)>=limit:
   RATE[key]=hits
   return False
  hits.append(now);RATE[key]=hits
  if len(RATE)>10000:
   for k in list(RATE)[:2000]:
    if not RATE[k] or RATE[k][-1]<now-window:RATE.pop(k,None)
  return True

def reconcile_interrupted_jobs():
 """Do not falsely report interrupted in-memory renders as still running."""
 count=0
 for path in (ROOT/'jobs').glob('*.json'):
  if not re.fullmatch(r'[a-f0-9]{32}\.json',path.name):continue
  try:
   j=json.loads(path.read_text(encoding='utf-8'))
   if j.get('status') in ('queued','running'):
    j.update(status='error',error='서버 재시작으로 렌더링이 중단되었습니다. 다시 생성해 주세요.',progress=0)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8');tmp.replace(path)
    count+=1
  except (OSError,ValueError,TypeError):pass
 return count
def send_email(to,subject,body):
 host=os.environ.get('MOAFILM_SMTP_HOST')
 if not host:raise ValueError('이메일 발송 설정이 없습니다 (SMTP)')
 msg=email.message.EmailMessage();msg['From']=os.environ['MOAFILM_SMTP_FROM'];msg['To']=to;msg['Subject']=subject;msg.set_content(body)
 with smtplib.SMTP(host,int(os.environ.get('MOAFILM_SMTP_PORT','587')),timeout=15) as smtp:
  smtp.starttls(context=ssl.create_default_context())
  smtp.login(os.environ['MOAFILM_SMTP_USER'],os.environ['MOAFILM_SMTP_PASSWORD'])
  smtp.send_message(msg)
def persist_job(jobid):
 path=ROOT/'jobs'/(jobid+'.json');tmp=path.with_suffix('.tmp')
 tmp.write_text(json.dumps(JOBS[jobid],ensure_ascii=False));tmp.replace(path)
def probe(path):
 p=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],capture_output=True,text=True,check=True,timeout=20)
 d=json.loads(p.stdout);v=next(s for s in d['streams'] if s['codec_type']=='video');return {'width':v['width'],'height':v['height'],'duration':float(d['format']['duration']),'fps':v.get('r_frame_rate','')}
def check_template(t):
 if not isinstance(t,dict) or not re.fullmatch('[a-f0-9]{12}',str(t.get('id',''))):raise ValueError('템플릿 ID 오류')
 if not isinstance(t.get('name'),str) or not 1<=len(t['name'])<=100:raise ValueError('템플릿 이름 오류')
 bg=ROOT/'backgrounds'/(t['id']+'.mp4')
 if not bg.is_file():raise ValueError('배경 영상 없음')
 if not isinstance(t.get('duration'),(int,float)) or not 1<=t['duration']<=180:raise ValueError('영상 길이 1~180초')
 if t.get('scenes') and (not isinstance(t['scenes'],list) or len(t['scenes'])>30):raise ValueError('장면 목록 오류')
 keys=set()
 for s in t.get('slots',[]):
  if not isinstance(s,dict) or s.get('type') not in ('photo','text'):raise ValueError('레이어 유형 오류')
  for k in ('x','y','w','h','start','end'):
   if not isinstance(s.get(k),(int,float)):raise ValueError('레이어 좌표 오류')
  if not (0<=s['x']<1 and 0<=s['y']<1 and 0<s['w']<=1-s['x']+1e-8 and 0<s['h']<=1-s['y']+1e-8 and 0<=s['start']<s['end']<=t['duration']+1e-6):raise ValueError('레이어 위치·시간 오류')
  if not isinstance(s.get('key'),str) or not re.fullmatch('[a-zA-Z_][a-zA-Z0-9_]{0,30}',s['key']):raise ValueError('레이어 키 오류')
  if s['key'] in keys:raise ValueError('레이어 식별자가 중복됩니다: '+s['key'])
  keys.add(s['key'])
  # Upload guidance is UI metadata, never passed into the video renderer.
  for field in ('guide_title','guide_description'):
   if field in s and (not isinstance(s[field],str) or len(s[field])>(120 if field=='guide_title' else 600)):
    raise ValueError('고객 안내 문구 길이 오류')
  if 'required' in s and not isinstance(s['required'],bool):raise ValueError('필수 여부 오류')
  kfs=s.get('keyframes',[])
  if not isinstance(kfs,list) or len(kfs)>30:raise ValueError('키프레임 개수 오류')
  last=-1
  for kf in kfs:
   if not isinstance(kf,dict) or any(not isinstance(kf.get(z),(int,float)) for z in ('time','x','y')):raise ValueError('키프레임 형식 오류')
   if not (s['start']<=kf['time']<=s['end'] and kf['time']>last and 0<=kf['x']<=1-s['w']+1e-8 and 0<=kf['y']<=1-s['h']+1e-8):raise ValueError('키프레임 시간·좌표 오류')
   last=kf['time']
 return t
def save_data_url(data,path,limit,kind):
 if not isinstance(data,str) or ',' not in data:raise ValueError('업로드 데이터 오류')
 raw=base64.b64decode(data.split(',',1)[1],validate=True)
 if not raw or len(raw)>limit:raise ValueError('파일 용량 제한 초과')
 path.write_bytes(raw)
 try:
  if kind=='video':
   p=probe(path)
   if not 1<=p['duration']<=180 or p['width']>3840 or p['height']>2160 or abs(p['width']/p['height']-16/9)>.03:raise ValueError('16:9 MP4, 1~180초만 지원')
  else:
   with Image.open(path) as im:
    im.verify()
 except Exception:
  path.unlink(missing_ok=True);raise
 return raw
def make_scene_background(t,jobid):
 """Build one video from sequential clips, with optional 0.5s crossfades."""
 scenes=t.get('scenes') or []
 if not scenes:return ROOT/'backgrounds'/(t['id']+'.mp4'),float(t['duration']),False
 clips=[]
 for scene in scenes:
  sid=scene.get('id','')
  if not re.fullmatch(r'[a-f0-9]{12}',sid):raise ValueError('장면 ID 오류')
  f=ROOT/'scenes'/(t['id']+'-'+sid+'.mp4')
  if not f.is_file():raise ValueError('장면 파일 없음')
  d=float(scene.get('duration',0))
  if not 1<=d<=180:raise ValueError('장면 길이 오류')
  clips.append((f,d))
 if len(clips)>30:raise ValueError('장면 최대 30개')
 transition=t.get('transition','cut')
 if transition not in ('cut','fade'):raise ValueError('전환 방식 오류')
 fade=0.5 if transition=='fade' and len(clips)>1 else 0
 total=sum(d for _,d in clips)-fade*(len(clips)-1)
 if total>180 or total<1:raise ValueError('전체 길이 1~180초')
 args=['ffmpeg','-hide_banner','-loglevel','error','-y']
 for f,_ in clips:args+=['-i',str(f)]
 filters=[]
 for i,(_,d) in enumerate(clips):
  filters.append(f'[{i}:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,trim=duration={d},setpts=PTS-STARTPTS,fps=30,settb=AVTB,format=yuv420p[s{i}]')
 if fade:
  cur='s0'; elapsed=clips[0][1]
  for i in range(1,len(clips)):
   label=f'm{i}';offset=round(elapsed-fade,3)
   filters.append(f'[{cur}][s{i}]xfade=transition=fade:duration={fade}:offset={offset}[{label}]')
   cur=label;elapsed+=clips[i][1]-fade
 else:
  cur='joined';filters.append(''.join(f'[s{i}]' for i in range(len(clips)))+f'concat=n={len(clips)}:v=1:a=0[{cur}]')
 out=ROOT/'jobs'/(jobid+'-joined.mp4')
 args+=['-filter_complex',';'.join(filters),'-map',f'[{cur}]','-an','-c:v','libx264','-preset','ultrafast','-crf','23','-pix_fmt','yuv420p','-t',str(total),str(out)]
 subprocess.run(args,check=True,capture_output=True,timeout=900)
 return out,total,True

def run_render(jobid,t,photos,values):
 job=JOBS[jobid]; job.update(status='running',progress=2)
 out=ROOT/'outputs'/(jobid+'.mp4')
 temp=[]
 try:
  W,H=1920,1080; duration=float(t['duration'])
  bg,duration,joined=make_scene_background(t,jobid)
  if joined:temp.append(bg)
  args=['ffmpeg','-hide_banner','-loglevel','error','-y','-stream_loop','-1','-i',str(bg)]
  # Optional separate soundtrack. The original Canva background audio is kept if no separate track is provided.
  music=ROOT/'music'/(t['id']+'.mp3')
  use_music=music.is_file()
  bg_has_audio=(not joined) and any(x.get('codec_type')=='audio' for x in json.loads(subprocess.run(['ffprobe','-v','error','-show_streams','-of','json',str(bg)],capture_output=True,text=True,check=True).stdout)['streams'])
  if use_music:args+=['-stream_loop','-1','-i',str(music)]
  audio_index=1 if use_music else 0

  filters=['[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,fps=30,trim=duration='+str(duration)+',setpts=PTS-STARTPTS[v0]']
  current='v0';index=2 if use_music else 1
  for s in t['slots']:
   if s['type']=='photo':
    key=s['key'];src=photos.get(key)
    if not src:
     if s.get('required',True):raise ValueError('사진 누락: '+key)
     continue
    f=ROOT/'photos'/(jobid+'-'+key+'.png');save_data_url(src,f,12_000_000,'image');temp.append(f)
    args+=['-loop','1','-framerate','30','-i',str(f)]
    w=max(2,round(s['w']*W/2)*2);h=max(2,round(s['h']*H/2)*2)
    filters.append(f'[{index}:v]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},format=yuva420p,setsar=1[p{index}]')
    x=round(s['x']*W);y=round(s['y']*H)
    kfs=s.get('keyframes',[])
    if kfs:
     def motion(axis,dim):
      pts=[(float(s['start']),round(s[axis]*dim))]+[(float(k['time']),round(k[axis]*dim)) for k in kfs]
      pts=sorted(dict(pts).items())
      expr=str(pts[-1][1])
      for j in range(len(pts)-2,-1,-1):
       a,b=pts[j],pts[j+1]
       delta=b[0]-a[0]
       lerp=f'({a[1]}+({b[1]}-{a[1]})*(t-{a[0]})/{delta})' if delta>0 else str(a[1])
       expr=f'if(lt(t,{b[0]}),{lerp},{expr})'
      return expr.replace(',',r'\,')
     ox,oy=motion('x',W),motion('y',H)
    else:ox,oy=str(x),str(y)
    filters.append(f'[{current}][p{index}]overlay=x={ox}:y={oy}:eval=frame:enable=\'between(t,{s["start"]},{s["end"]})\':shortest=0[v{index}]')
    current='v'+str(index);index+=1
   else:
    content=str(values.get(s['key'],''))[:100]
    if not content:continue
    textfile=ROOT/'jobs'/(jobid+'-'+s['key']+'.txt');textfile.write_text(content,encoding='utf-8');temp.append(textfile)
    x=round(s['x']*W);y=round(s['y']*H);fontsize=max(14,min(150,round(s['h']*H*.6)))
    safe=str(textfile).replace('\\','/').replace(':','\\:').replace("'","\\'")
    filters.append(f'[{current}]drawtext=fontfile={FONT}:textfile={safe}:fontsize={fontsize}:fontcolor=white:borderw=2:bordercolor=black@0.65:x={x}:y={y}:enable=\'between(t,{s["start"]},{s["end"]})\'[v{index}]')
    current='v'+str(index);index+=1
  args+=['-filter_complex',';'.join(filters),'-map','['+current+']']
  if use_music or bg_has_audio:args+=['-map',f'{audio_index}:a:0','-c:a','aac','-b:a','192k','-af',f'afade=t=out:st={max(0,duration-2)}:d={min(2,duration)}']
  else:args+=['-an']
  args+=['-t',str(duration),'-c:v','libx264','-preset','ultrafast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart','-progress','pipe:1','-nostats',str(out)]
  p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  job['pid']=p.pid
  for line in p.stdout:
   if line.startswith('out_time_ms='):
    try:job['progress']=min(99,max(2,int(float(line.split('=',1)[1])/1e6/duration*100)))
    except ValueError:pass
  err=p.stderr.read();rc=p.wait()
  if rc:raise RuntimeError('FFmpeg 출력 실패: '+err[-1200:])
  meta=probe(out)
  if meta['width']!=1920 or meta['height']!=1080 or abs(meta['duration']-duration)>.15:raise RuntimeError('결과 영상 검증 실패')
  job.update(status='done',progress=100,download='/outputs/'+jobid+'.mp4',meta=meta);persist_job(jobid)
 except Exception as e:
  out.unlink(missing_ok=True);job.update(status='error',error=str(e));persist_job(jobid)
 finally:
  for f in temp:f.unlink(missing_ok=True)
class Handler(BaseHTTPRequestHandler):
 def identity(self):return security.current(self.headers.get('Cookie',''))
 def require(self,admin=False):
  user=self.identity()
  if not user:self.send(401,{'error':'로그인이 필요합니다'});return None
  if admin and user['role']!='admin':self.send(403,{'error':'관리자 권한이 필요합니다'});return None
  return user
 def secure_headers(self):
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'")

 def send(self,code,obj):
  raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.secure_headers();self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  path=unquote(urlparse(self.path).path)
  if path=='/api/me':return self.send(200,self.identity() or {'role':'guest'})
  if path=='/api/templates':
   if not self.require():return
   return self.send(200,[json.loads(f.read_text()) for f in (ROOT/'templates').glob('*.json')])
  if path.startswith('/api/job/'):
   user=self.require()
   if not user:return
   jobid=path.rsplit('/',1)[-1]
   with security.db() as c:owner=c.execute('SELECT user_id FROM render_jobs WHERE job_id=?',(jobid,)).fetchone()
   if not owner or owner['user_id']!=user['id']:return self.send(404,{'error':'작업 없음'})
   j=JOBS.get(jobid)
   if not j and (ROOT/'jobs'/(jobid+'.json')).is_file():j=json.loads((ROOT/'jobs'/(jobid+'.json')).read_text())
   return self.send(200,j) if j else self.send(404,{'error':'작업 없음'})
  if path=='/':file=ROOT/'index.html'
  elif path.startswith('/outputs/') and re.fullmatch(r'/outputs/[a-f0-9]{32}\.mp4',path):
   user=self.require()
   if not user:return
   jobid=path.split('/')[-1][:-4]
   with security.db() as c:owner=c.execute('SELECT user_id FROM render_jobs WHERE job_id=?',(jobid,)).fetchone()
   if not owner or owner['user_id']!=user['id']:return self.send(404,{'error':'파일 없음'})
   file=ROOT/path.lstrip('/')
  elif path.startswith('/backgrounds/') and re.fullmatch(r'/backgrounds/[a-f0-9]{12}\.mp4',path):
   if not self.require():return
   file=ROOT/path.lstrip('/')
  else:return self.send(404,{'error':'파일 없음'})
  if not file.is_file():return self.send(404,{'error':'파일 없음'})
  mime=mimetypes.guess_type(str(file))[0] or 'application/octet-stream';size=file.stat().st_size
  self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(size));self.secure_headers();self.end_headers()
  with file.open('rb') as f:shutil.copyfileobj(f,self.wfile)
 def do_POST(self):
  try:
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<=35_000_000:raise ValueError('요청 크기 제한 초과')
   origin=self.headers.get('Origin')
   if origin and origin not in (f'http://{HOST}:{PORT}',f'http://localhost:{PORT}',os.environ.get('MOAFILM_PUBLIC_ORIGIN','')):raise ValueError('허용되지 않은 요청 출처')
   data=json.loads(self.rfile.read(length));path=urlparse(self.path).path
   if path in ('/api/login','/api/register','/api/password/forgot','/api/password/reset','/api/email/verify'):
    ip=self.client_address[0]
    limits={'/api/login':(12,300),'/api/register':(5,3600),'/api/password/forgot':(5,3600),'/api/password/reset':(10,3600),'/api/email/verify':(10,3600)}
    limit,window=limits[path]
    email=str(data.get('email','')).strip().lower()[:254]
    if not check_rate(('ip',ip,path),limit,window) or (email and not check_rate(('email',email,path),limit*2,window)):
     return self.send(429,{'error':'요청이 너무 많습니다. 잠시 후 다시 시도하세요.'})
   if path=='/api/register':
    user=security.register(data.get('email',''),data.get('password',''))
    if os.environ.get('MOAFILM_SMTP_HOST'):
     token=security.create_token(user['email'],'email_verifications')
     base=os.environ.get('MOAFILM_PUBLIC_ORIGIN',f'http://{HOST}:{PORT}')
     send_email(user['email'],'모아필름 이메일 인증',f'인증 토큰: {token}\n사이트에서 이메일 인증에 사용하세요. (30분 유효)\n{base}')
    return self.send(200,{'user':user,'email_verification_required':bool(os.environ.get('MOAFILM_SMTP_HOST'))})
   if path=='/api/password/forgot':
    email=str(data.get('email',''))
    token=security.create_token(email,'password_resets')
    if token and os.environ.get('MOAFILM_SMTP_HOST'):
     send_email(email,'모아필름 비밀번호 재설정',f'재설정 토큰: {token}\n30분 이내에 사용하세요.')
    return self.send(200,{'ok':True,'message':'계정이 존재하고 메일 설정이 되어 있으면 안내 메일이 발송됩니다'})
   if path=='/api/password/reset':
    security.reset_password(str(data.get('token','')),str(data.get('password','')))
    return self.send(200,{'ok':True})
   if path=='/api/email/verify':
    security.verify_email(str(data.get('token','')))
    return self.send(200,{'ok':True})
   if path=='/api/login':
    token,user=security.login(data.get('email',''),data.get('password',''))
    if os.environ.get('MOAFILM_REQUIRE_VERIFIED')=='1':
     with security.db() as c:verified=c.execute('SELECT verified FROM users WHERE id=?',(user['id'],)).fetchone()[0]
     if not verified and user['role']!='admin':raise ValueError('이메일 인증이 필요합니다')
    raw=json.dumps({'user':user},ensure_ascii=False).encode();self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Set-Cookie','moafilm_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400'+('; Secure' if os.environ.get('MOAFILM_HTTPS')=='1' else ''));self.secure_headers();self.end_headers();self.wfile.write(raw);return
   if path=='/api/logout':
    security.logout(self.headers.get('Cookie',''));return self.send(200,{'ok':True})
   user=self.require(admin=path in ('/api/template','/api/scene','/api/music','/api/template/update','/api/marker/detect'))
   if not user:return
   if path=='/api/marker/detect':
    ident=str(data.get('template_id',''))
    if not re.fullmatch(r'[a-f0-9]{12}',ident):raise ValueError('템플릿 ID 오류')
    template_path=ROOT/'templates'/(ident+'.json')
    if not template_path.is_file():raise ValueError('템플릿 없음')
    t=json.loads(template_path.read_text(encoding='utf-8'))
    tmp=ROOT/'jobs'/(uuid.uuid4().hex+'.guide.mp4')
    try:
     save_data_url(data.get('video'),tmp,25_000_000,'video')
     result=detect_video(tmp)
     if abs(result['duration']-float(t['duration']))>.25:raise ValueError('인식용 영상과 배경 영상 길이가 다릅니다 (허용 오차 0.25초)')
     # Detection is a preview only; admin must confirm and save separately.
     return self.send(200,result)
    finally:tmp.unlink(missing_ok=True)
   if path=='/api/checkout/mock':
    ident=str(data.get('template_id',''))
    if not re.fullmatch('[a-f0-9]{12}',ident) or not (ROOT/'templates'/(ident+'.json')).is_file():raise ValueError('템플릿 없음')
    order=uuid.uuid4().hex
    with security.db() as c:c.execute('INSERT INTO orders VALUES(?,?,?,?,?)',(order,user['id'],ident,'mock_paid',int(time.time())))
    return self.send(200,{'order_id':order,'status':'mock_paid','real_charge':False})
   if path=='/api/template':
    ident=uuid.uuid4().hex[:12];bg=ROOT/'backgrounds'/(ident+'.mp4')
    save_data_url(data['video'],bg,25_000_000,'video')
    meta=probe(bg);t={'id':ident,'name':str(data.get('name','Canva 템플릿'))[:100],'duration':round(meta['duration'],3),'slots':[]}
    (ROOT/'templates'/(ident+'.json')).write_text(json.dumps(t,ensure_ascii=False,indent=2));return self.send(200,t)
   if path=='/api/scene':
    ident=data.get('template_id','')
    if not re.fullmatch('[a-f0-9]{12}',ident) or not (ROOT/'templates'/(ident+'.json')).is_file():raise ValueError('템플릿 없음')
    sid=uuid.uuid4().hex[:12]
    target=ROOT/'scenes'/(ident+'-'+sid+'.mp4')
    save_data_url(data['video'],target,25_000_000,'video')
    return self.send(200,{'id':sid,'duration':round(probe(target)['duration'],3)})
   if path=='/api/music':
    ident=data.get('template_id','')
    if not re.fullmatch('[a-f0-9]{12}',ident) or not (ROOT/'templates'/(ident+'.json')).is_file():raise ValueError('템플릿 없음')
    audio=data.get('audio','')
    if not isinstance(audio,str) or not audio.startswith('data:audio/'):raise ValueError('오디오 파일 형식 오류')
    target=ROOT/'music'/(ident+'.mp3')
    raw=base64.b64decode(audio.split(',',1)[1],validate=True)
    if len(raw)>20_000_000:raise ValueError('음원 20MB 제한')
    tmp=ROOT/'jobs'/(uuid.uuid4().hex+'.audio');tmp.write_bytes(raw)
    try:
     subprocess.run(['ffmpeg','-v','error','-y','-i',str(tmp),'-vn','-c:a','libmp3lame','-b:a','192k',str(target)],check=True,timeout=90,capture_output=True)
    finally:tmp.unlink(missing_ok=True)
    return self.send(200,{'ok':True})
   if path=='/api/template/update':
    t=check_template(data['template']);(ROOT/'templates'/(t['id']+'.json')).write_text(json.dumps(t,ensure_ascii=False,indent=2));return self.send(200,{'ok':True})
   if path=='/api/render':
    ident=data.get('template_id','')
    if not re.fullmatch('[a-f0-9]{12}',ident):raise ValueError('템플릿 ID 오류')
    t=check_template(json.loads((ROOT/'templates'/(ident+'.json')).read_text()))
    photos=data.get('photos',{});values=data.get('values',{})
    if not isinstance(photos,dict) or not isinstance(values,dict):raise ValueError('입력 형식 오류')
    required={s['key'] for s in t['slots'] if s['type']=='photo' and s.get('required',True)}
    if required-set(photos):raise ValueError('사진 누락: '+', '.join(sorted(required-set(photos))))
    order_id=data.get('order_id')
    if user['role']!='admin':
     with security.db() as c:paid=c.execute('SELECT 1 FROM orders WHERE id=? AND user_id=? AND template_id=? AND status=?',(order_id,user['id'],ident,'mock_paid')).fetchone()
     if not paid:raise ValueError('테스트 결제 완료 후 렌더링할 수 있습니다')
    jobid=uuid.uuid4().hex;JOBS[jobid]={'status':'queued','progress':0};persist_job(jobid)
    with security.db() as c:c.execute('INSERT INTO render_jobs VALUES(?,?,?)',(jobid,user['id'],order_id))
    threading.Thread(target=run_render,args=(jobid,t,photos,values),daemon=True).start();return self.send(200,{'job_id':jobid})
   return self.send(404,{'error':'API 없음'})
  except Exception as e:return self.send(400,{'error':str(e)})
 def log_message(self,*a):pass
if __name__=='__main__':
 print(f'MoaFilm Canva Studio: http://{HOST}:{PORT}',flush=True)
 print('Interrupted jobs reconciled:',reconcile_interrupted_jobs(),flush=True)
 ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
